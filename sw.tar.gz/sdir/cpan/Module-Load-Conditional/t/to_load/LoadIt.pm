package LoadIt;
use strict;

our $VERSION = 1;

1;
