﻿package Heart;

our $VERSION = 1;

package BOMTest::UTF8;

our $VERSION = 3;

package Cœur;

our $VERSION = 2;

1;
